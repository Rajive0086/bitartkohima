<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Career and Events</title>
	<?php $this->load->view('common/css'); ?>
    <style type="text/css">
      .header-fixed {
       
        }

        .header-hidden {
	       
            position: fixed;
        }

        .hero {
            background:  url('<?php echo base_url(); ?>images/.jpg') center / cover;
        }
        
        @media (max-width: 1024px) { .hero { background:  url('<?php echo base_url(); ?>images/.jpg') center / cover; } 
        .mobile{padding:0px 20px !important}
        }
        @media (max-width:  768px) { .hero { background:  url('<?php echo base_url(); ?>images/.jpg') center / cover;  } 
               
        }
        @media (max-width: 768px) {
            :root {
                font-size: 100%;
            }
            .footer-mobile
            {
                padding-left:20px;
                padding-right:20px;
            }
           
        }
        hr{
   height:3px;
   background-color:yellow;
   border:none;
   width:20%;
   
}
    </style>
</head>
<body bgcolor=#F8F8F8>
<section class="hero is-medium" style="background-color:#d0dbdd !important ;height:300px !important;">
	<!-- .navbar -->
	<?php $this->load->view('common/navbar-2'); ?>
	<!-- /.navbar -->
    <div class="hero-body ">
        <div class="is-overlay has-text-centered single-spaced" style="top: 140px;">
            <div> 
                
				<h3 class="  roboto" style="color: #3ac7c7;font-weight:600;font-size:2.5rem !important;line-height:0px !important">Support & Services</h1>	
                <h2 class="subtitle is-4 has-text-weight-light has-text-white " style="line-height:29px !important"><br>Areas what we serve </h2>						
                <div class="subtitle has-text-centered control">
                   
                </div>
            </div>
        </div>
    </div>
    </section>
<section class=section>
 <!--  <main class="hero-foot center" style="padding:0px 100px; margin-top:-200px; margin-bottom:100px;">
    <div class="columns " >
        <div class="column is-4 "style="padding:0px 20px;"  >
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 " >
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-one.svg" alt="Placeholder image" class="modal-button" data-target="modal-image2">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Articles</h4>
                <p class=has-text-black>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eum vero quibusdam asperiores deleniti, ducimus odio illo? Natus mollitia ducimus, reprehenderit fugiat pariatur incidunt. </p>
                <span class="button is-link modal-button" data-target="modal-image2">Image modal</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4  " style="padding:0px 20px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image">
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-two.svg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Articles</h4>
                <p class=has-text-black>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Praesentium labore quod saepe perspiciatis harum voluptatibus qui quo atque velit distinctio et iure est laudantium, </p>
                <span class="button is-link modal-button" data-target="modal-card">Modal Card</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4 " style="padding:0px 20px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-three.svg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-blacke>Articles</h4>
                <p class=has-text-black>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis eligendi sit id omnis temporibus tempora sequi officiis molestias repellat in quis qui possimus dolores, </p>
                <span class="button is-link modal-button" data-target="modal-image">Image modal</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
  </main>		 -->	

  	
  <main class="hero-foot center mobile" style="padding:0px 100px; ; margin-bottom:100px;">
    <div class="columns " >
        <div class="column is-4 "style="padding:0px 20px;"  >
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 " >
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-one.svg" alt="Placeholder image" class="modal-button" data-target="modal-image2">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Infrastructure  & Network</h4>
                <p class=has-text-black>Lorem ipsum   quidem repellat eos quae dolor dicta hic sit, quam rem culpa commodi veniam fuga ducimus natus illum nostrum!</p>
                <span class="button is-link modal-button" data-target="modal-image2">Explore</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4  " style="padding:0px 20px ; ">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image">
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-two.svg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Securuty Servilance</h4>
                <p class=has-text-black>  maiores excepturi recusandae  inventore natus repellat autem vero praesentium voluptates! Tempore beatae corporis earum!</p>
                <span class="button is-link modal-button" data-target="modal-card">Explore</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4 " style="padding:0px 20px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-three.svg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-blacke>Comminication System</h4>
                <p class=has-text-black>incidunt accusamus eaque ex veritatis dolorem voluptatibus, consequuntur provident facere enim quam!</p>
                <span class="button is-link modal-button" data-target="modal-image">Explore<span>
              </div>
            </div>
          </div>
        </div>
        
      </div>
      
  </main>		
  <main class="hero-foot center mobile" style="padding:0px 100px; margin-top:-20px; margin-bottom:100px;">
    <div class="columns " >
        <div class="column is-4 "style="padding:0px 5px;"  >
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 " >
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-one.svg" alt="Placeholder image" class="modal-button" data-target="modal-image2">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Custom Software</h4>
                <p class=has-text-black>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Qui, ut? Ipsam sint nobis veritatis itaque, eveniet corrupti vitae eum mollitia nisi pariatur. Molestias culpa fugiat dolorem. Aut, ipsam. Incidunt, odio.</p>
                <span class="button is-link modal-button" data-target="modal-image2">Explore</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4  " style="padding:0px 5px ; ">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image">
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-two.svg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Website</h4>
                <p class=has-text-black>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque neque in eius, maxime ab nesciunt dolore et eveniet velit autem placeat omnis perspiciatis beatae aut totam modi voluptatum eligendi perferendis. </p>
                <span class="button is-link modal-button" data-target="modal-card">Explore</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4 " style="padding:0px 5px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/illustration-three.svg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-blacke>Mobile Application</h4>
                <p class=has-text-black> Lorem, ipsum dolor adipisicing elit. Maxime temporibus explicabo unde, id facilis perferendis suscipit quisquam sit rerum, ratione porro laboriosam quae deserunt. Eius autem tempora voluptate at explicabo!</p>
                <span class="button is-link modal-button" data-target="modal-image">Explore<span>
              </div>
            </div>
          </div>
        </div>
        
      </div>
      
  </main>	

</section>
<section class="hero is-fullheight" style="background-image:url('<?php echo base_url();?>images/);">
    <div class=columns>
        <div class="column is-two-third" style="padding:50px;" >
            <h1 class="title is-4 has-text-black">CAREERS EVENTS</h1>
            <p class=has-text-black>Let’s meet up. We could be in a town near you soon and we’re ready to connect you with the next leaders in technology, communications and entertainment. So, come out and say hi.</p>
            <div class="subtitle  control">
                    <a class="button is-info">
                        Join Us 
                    </a>
            </div>
        </div>
        <div class="column is-one-third">
            <div class="card-image" >
              <figure class="image is-4by3" >
                <img src="<?php echo base_url();?>images/illustration-shopping.svg" alt="Placeholder image" class="modal-button" data-target="modal-image2">
              </figure>
            </div>
        </div>
    </div>
</section>


<!-- .Footer -->
<?php $this->load->view('common/footer'); ?>
<!-- /.Footer -->

<!-- .Scripts -->
<?php $this->load->view('common/scripts'); ?>
<!-- /.Scripts -->	
<script>
$(() => {
  $('#edit-preferences').click(function(){
   $('#edit-preferences-modal').addClass('is-active');
  });
  $('.modal-card-head button.delete, .modal-save, .modal-cancel').click(function(){
    $('#edit-preferences-modal').removeClass('is-active');
  });
});
</script>
<body>
