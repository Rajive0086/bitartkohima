<aside class="column is-2 aside">
        <nav class="menu">
          <p class="menu-label">
         
          </p>
          <ul class="menu-list">
            <li><a class="is-active" href="#"><span class="icon is-small"><i class="fa fa-tachometer"></i></span> Dashboard</a></li>
          </ul>
          <p class="menu-label">
            
          </p>
          <ul class="menu-list">
            <li><a href="<?php echo base_url() ?>Recruiter/JobPost"><span class="icon is-small"><i class="fa fa-pencil-square-o"></i></span> Job Post</a></li>
            <li><a href="/bulma-admin-dashboard-template/ui-elements.html"><span class="icon is-small"><i class="fa fa-desktop"></i></span>View Candidate </a></li>
            <li><a href="/bulma-admin-dashboard-template/tables.html"><span class="icon is-small"><i class="fa fa-table"></i></span>Schedule Interview </a></li>
         

            <li>
              <a class=""><i class="fa fa-cog"></i> Manage Jobs</a>
              <ul>
                <li><a>Active</a></li>
                <li><a>De-Active</a></li>
                <li><a>Progress</a></li>
              </ul>
            </li>
          </ul>
          <p class="menu-label">
            Live On
          </p>
          <ul class="menu-list">
            <li><a><span class="icon is-small"><i class="fa fa-bug"></i></span> Profile</a></li>
            
            <li><a><span class="icon is-small"><i class="fa fa-laptop"></i></span> Sign Out</a></li>
          </ul>
        </nav>
      </aside>