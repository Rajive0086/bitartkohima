<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>images/logo.ico" type="image/x-icon">
    <link href="<?php echo base_url(); ?>assets/css/bulma.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/css/njc.css" rel="stylesheet" type="text/css" />
    <script defer src="https://use.fontawesome.com/releases/v5.0.10/js/all.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/grid.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/helpers.css">
    <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/animate.css"> -->
    <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/debug.v3.css"> -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bulma-carousel/dist/css/bulma-carousel.min.css">
   <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Barlow+Semi+Condensed|Source+Sans+Pro|Exo+2|Anton|Roboto|Lato|Oswald|Staatliches|Dosis|Slabo+27px|Roboto+Condensed|Open+Sans|Arvo|Dosis|Titillium+Web|Source+Sans+Pro|Srisakdi" rel="stylesheet">
    <!-- /google fonts -->
