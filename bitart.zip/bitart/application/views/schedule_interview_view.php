<head>
    <title>Job Post</title>
</head>
<div class="content-wrapper">
 <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      <p class=has-text-warning><a href="#" class="sidebar-toggle heading has-text-info" data-toggle="push-menu" role="button">
      <i class="fal fa-arrow-to-left ">Menu Items</i>
          </a></p>
        <i class="fa fa-users"></i> Schedule Interview
       
      </h1>
    </section>
    <section class="content">
        <div class="card-table">
            <div class="content">
                <table class="table is-fullwidth is-striped">
                    <tbody>
                        <tr>
                            <th width="5%"><i class="fa fa-bell-o"></i></td>
                            <th>Job Title</td>
                            <th>Schedule Date</td>
                            <th><a class="button is-small is-primary center is-fullwide" href="#">Action</a></td>
                            <th class=desktop>Conformed</td>
                        </tr>
                        <tr>
                            <td width="5%"><i class="fa fa-bell-o"></i></td>
                            <td>Senior Web Developer Position- Laravel PHP</td>
                            <td>--/--/-->&nbsp;</td>
                            <td><a class="button is-small is-primary center is-fullwide" href="#">Pick Date</a></td>
                            <td class=desktop>no</td>
                        </tr>
                        <tr>
                            <td width="5%"><i class="fa fa-bell-o"></i></td>
                            <td>Customer Service Executive (International)</td>
                            <td>--/--/-->&nbsp;</td>
                            <td><a class="button is-small is-primary center is-fullwide" href="#">Pick Date</a></td>
                            <td class=desktop>yes</td>
                            
                        </tr>
                        <tr>
                            <td width="5%"><i class="fa fa-bell-o"></i></td>
                            <td>Web Developer (ASP.Net)</td>
                            <td>2/3/2019&nbsp;</td>
                            <td><a class="button is-small is-primary center is-fullwide" href="#">Change</a></td>
                            <td class=desktop>Yes</td>
                            
                        </tr>
                        <tr>
                            <td width="5%"><i class="fa fa-bell-o"></i></td>
                            <td>Fresher Software Web Develoepr Programmer</td>
                            <td>2/9/2018&nbsp;</td>
                            <td><a class="button is-small is-lite center is-fullwide" href="#">Change</a></td>
                            <td class="has-text-danger desktop ">Deactive</td>
                           
                            
                        </tr>   
                        
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

</body>

<!-- .Footer -->
