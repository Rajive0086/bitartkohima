

    <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Powered by:-</b> Bitart | Version 1.0
        </div>
        <strong>Copyright &copy; 2019-2020 <a href="<?php echo base_url(); ?>">NJC</a>.</strong> All rights reserved.
    </footer>
    
    <script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js" type="text/javascript"></script>
    <!-- <script src="<?php echo base_url(); ?>assets/dist/js/pages/dashboard.js" type="text/javascript"></script> -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.validate.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/validation.js" type="text/javascript"></script>
   
  </body>
</html>