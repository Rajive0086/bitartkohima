<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bitart</title>
	<?php $this->load->view('common/css'); ?>
<!-- .inline-css -->
<style type="text/css">
    .hero { background:  url('<?php echo base_url(); ?>images/bg_low.jpg') center / cover; }
    .quot { padding:5px 80px; }
    @media (max-width: 1024px){
        .hero { background:  url('<?php echo base_url(); ?>images/bg_low.jpg') center / cover; }
        .quot { padding:5px 10px; }
    }
    @media (max-width:  768px){
         .hero { background:  url('<?php echo base_url(); ?>images/bg_low.jpg') center / cover; }
         .quot { padding:5px 10px; }
    }
    @media (max-width: 768px){
        :root { font-size: 100%; }
        .footer-mobile {
                padding-left:20px;
                padding-right:20px;
        }
        .quot { padding:5px 10px; }
    }
    hr{
       height:3px;
       background-color:yellow;
       border:none;
       width:20%;
    }
</style>
 <!-- /.inline-css -->
</head>
<body>
<!-- .hero -->
<section class="hero is-fullheight">
	<!-- .navbar -->
	<?php $this->load->view('common/navbar'); ?>
  <!-- /.navbar -->
  
    <div class="hero-body">
        <div class="is-overlay has-text-centered single-spaced" style="top: 140px;">
            <div id="heroMessage" style=" padding:50px;background-color: #0007">
            <h1 class="title is-1 has-text-white">Bitart</h1>
                <h2 class="subtitle is-4 has-text-weight-light has-text-white">A Social Impact, IT based Entrepreneur</h2>
                <h3 class="title is-2"> </h3>
			
            </div>
        </div>
        
    </div>
	  <main class="hero-foot center" style="padding: 2rem; background-color:#0009">
        <div id="grid" style="width: 768px;">
            <div id="a" class="center-column">
                <h2 class="subtitle has-text-centered has-text-white">
               
                </h2>
            </div>
            <div id="b" class="center-column">
                <p class="heading has-text-white">
                    <i class="fas fa-tachometer-alt has-text-grey-light"
                        style="width: 0.75em; height: 0.75em;"></i>
                    Developers<span class="is-size-5"></span>
                </p>
                <p class="subtitle has-text-white is-7">13</p>
            </div>
            <div id="c" class="center-column" style="border-left: 1px solid gray;">
                <p class="heading has-text-white"><span class="is-size-5"></span>clients<span class="is-size-5"></span></p>
                <p class="subtitle is-7 has-text-white">100</p>
            </div>
            <div id="d" class="center-column" style="border-left: 1px solid gray;">
                <p class="heading has-text-white">Free Lancers<span class="is-size-5"></span></p>
                <p class="subtitle is-7 has-text-white">300</p>
            </div>
            <div id="e" class="center-column">
                <a class="button is-danger is-inverted is-rounded is-outlined has-text-weight-bold"
                    style="width: 100%; ">
                    Register
                </a>
            </div>
        </div>
    </main>
</section>
<!-- /.hero -->

 <!---------------- .About NJC ----------------->
<section class="section" style="background:;padding-bottom:1px;margin-bottom:0">
		 <div class="container">
				 <div class="section-heading who-we-are">
                     <h2 class="subtitle is-4 has-text-weight-light has-text-gray">We exist to empower our clients with technology that creates meaningful social impact in their world.</h2>
					 <h4 class="subtitle is-5"><em></em></h4>
					 <div class="container">
						
					 </div>
				 </div>
		 </div>
 </section>
 <!---------------- /.About NJC----------------->


	 <!---------------- .Job Listing Section----------------->
	<section class="section" style="background:#EFF3F4;">
				<!--  container -->
			<div class="container">
				<div class="section-heading who-we-are">
					<h3 class="title is-2 title-chin">Specility</h3>
				</div>
					<!-- ---------- .columns -------------->
					<div class="columns" id="job-opening-column">
							<!-- ---------- .column -------------->
							
                            <div class="column card  has-background-white" style="padding:30px;">
										<div class="columns is-mobile" style="margin-top:1px;">
                                            <div class="column tag  is-offset-10 is-2"></div>
                  	                    </div>
									    <div class="clear" style="clear:both;"><h1 class="title is-4 ">CUSTOM SOFTWARE</h1> </div>
									    <div class="content">
											 
													 <div id="b" class="" style="">
															 <h4 class="has-text-black" ></h4>
															 
															 <p class="has-text-grey" style="margin-top:-15px;font-weight:300;font-size:22px;">Our team is skilled at developing solutions using pretty much any modern programming language.</p>
															
													 </div>
										</div>
										
											
									</div>
                                    <div class="column card  has-background-white " style="padding:30px;" >
										<div class="columns is-mobile" style="margin-top:1px;">
                                            <div class="column tag  is-offset-10 is-2"></div>
                  	                    </div>
									    <div class="clear" style="clear:both;"><h1 class="title is-4 ">WEBSITE</h1> </div>
									    <div class="content">
											 
													 <div id="b" class="" style="">
															 <h4 class="has-text-black" ></h4>
															 
															 <p class="has-text-grey" style="margin-top:-15px;font-weight:300;font-size:22px;">We can build any type or size website you require, from small custom designed websites to highly advanced online stores.</p>
															
													 </div>
										</div>
										
											
									</div>
                                    <div class="column card  has-background-white" style="padding:30px;">
										<div class="columns is-mobile" style="margin-top:1px;">
                                            <div class="column tag is-danger is-offset-10 is-2">New</div>
                  	                    </div>
									    <div class="clear" style="clear:both;"><h1 class="title is-4 ">INFRASTRUCTER & NETWORK SOLUTIONS</h1> </div>
									    <div class="content">
											 
													 <div id="b" class="" style="">
															 <h4 class="has-text-black" ></h4>
															 
															 <p class="has-text-grey" style="margin-top:-15px;font-weight:300;font-size:22px;">Whether the app is for internal or customer-facing use we make sure it’s exactly what you need to reach your goals.</p>
															
													 </div>
										</div>
										
											
									</div>
                                    

									
                                    
							
						 <!-- ---------- ./column -------------->

					</div>
					<!-- ---------- ./columns -------------->
							<div class="columns   is-vcentered is-centered " style="margin-top:25px;">
									<div class="column  is-full center">
										<a href="<?php echo base_url() ?>Career" class="button  is-link is-outlined ">Explore </a>
									</div>
							</div>

			</div>
		 <!--  ./container -->
</section>
<!--------------- /.Jobs Listing section ----------------------->

<section>
<main class="container"  style="padding:50px 0px">
<div class="section-heading who-we-are">
					<h3 class="title is-2 title-chin">Latest Work, News & Thoughts</h3>
				</div>
    <div class="columns " >
        <div class="column is-4 "style="padding:0px 20px;"  >
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 " >
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/sbck.jpg" alt="Placeholder image" class="modal-button" data-target="modal-image2">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Sema Baptist Church Kohima</h4>
                <p class=has-text-black>Lorem Eum vero quibusdam odio illo? Natus mollitia ducimus, reprehenderit fugiat pariatur incidunt. </p>
                <span class="button is-link modal-button" data-target="modal-image2">Image modal</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4  " style="padding:0px 20px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image">
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/de-oriental.jpg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>De Oriental Grand  </h4>
                <p class=has-text-black>Lorem ipsuing elit. Praesentium labore perspiciatis harum voluptatibus qui quo atque velit distinctio et iure est laudantium, </p>
                <span class="button is-link modal-button" data-target="modal-card">Modal Card</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4 " style="padding:0px 20px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/ag.jpg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-blacke>Ag Nagaland</h4>
                <p class=has-text-black>Lorem ipsum dolor ligendi sit id omnis temporibus tempora sequi officiis molestias repellat in quis qui possimus dolores, </p>
                <span class="button is-link modal-button" data-target="modal-image">Image modal</span>
              </div>
            </div>
          </div>
        </div>
    </div>
    <div class="columns " >
        <div class="column is-4 "style="padding:0px 20px;"  >
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 " >
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/mtc.jpg" alt="Placeholder image" class="modal-button" data-target="modal-image2">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>Mon Theological College</h4>
                <p class=has-text-black>Lorem Eum vero quibusdam odio illo? Natus mollitia ducimus, reprehenderit fugiat pariatur incidunt. </p>
                <span class="button is-link modal-button" data-target="modal-image2">Image modal</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4  " style="padding:0px 20px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image">
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/givf.jpg" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-black>GIVF Hospital  </h4>
                <p class=has-text-black>Lorem ipsuing elit. Praesentium labore perspiciatis harum voluptatibus qui quo atque velit distinctio et iure est laudantium, </p>
                <span class="button is-link modal-button" data-target="modal-card">Modal Card</span>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4 " style="padding:0px 20px;">
          <div class=" is-shady borderless box" style=" box-shadow: 1px 15px 20px 1px #E0E0E0 ">
            <div class="card-image" >
              <figure class="image is-4by3" style="padding:60px;">
                <img src="<?php echo base_url();?>images/hum.png" alt="Placeholder image">
              </figure>
            </div>
            <div class="card-content">
              <div class="content content-align-center">
                <h4 class=has-text-blacke>Music Hub</h4>
                <p class=has-text-black>Lorem ipsum dolor ligendi sit id omnis temporibus tempora sequi officiis molestias repellat in quis qui possimus dolores, </p>
                <span class="button is-link modal-button" data-target="modal-image">Image modal</span>
              </div>
            </div>
          </div>
        </div>
    </div>
  </main>	
  <div class="columns   is-vcentered is-centered " style="margin-top:25px;">
									<div class="column  is-full center">
										<a href="<?php echo base_url() ?>jobs" class="button  is-link is-outlined ">Explore </a>
									</div>
							</div>
</section>


<!--- .section carousel ------------->
<!-- <section class=section style="background-image:url('<?php echo base_url(); ?>images/try.jpg');background-size:cover;width:100%;height:500px;">
    <h1 class="subtitle is-1 has-text-info ftStaatliches ftco-animated" align=center style="margin-top:-40px;">Testimonial </h1>
    <h5 class="subtitle is-6    has-text-success" align=center style="margin-top:-30px;">FROM OUR CLIENTS AND CANDIDATES </h5>

     <div class='carousel carousel-animated carousel-animate-slide' data-autoplay="true" data-delay="8000">
        <div class='carousel-container'>
            <div class='carousel-item  is-active' style="width:100%;height:380px;">
                <main class="hero-foot center" style="padding: 2rem;">
                    <div id="grid" style="width: 768px;">
                        <div id="a" class="center-column">
                            <p class="has-text-centered has-text-black">
                            Thank God for Nagaland Job Centre!!
                        It has really become convenient for business persons like us to employ staffs, all we have to do is make a call, tell them our preferences and the interview is arranged. The <strong class=has-text-warning   >service is quick </strong> and the staffs are pleasant to talk to. I wish them all the best and more success in coming years.
                            </p>
                            <div id="a" class="center-column">
                            <img src="<?php echo base_url(); ?>images/avatar-4.jpg" style=" height:100px;width:100px;border-radius:50%;">

                        </div>



                        <div id="e" class="">
                            <p  class="is-danger is-inverted is-rounded is-white is-outlined has-text-weight-bold"
                                style="width: 100%; ">
                                Zubeni Kikon, Reliance Motors
                            </p>
                        </div>
                    </div>
					</div>
                </main>
            </div>
            <div class='carousel-item' style="width:100%;height:380px;">
                <main class="hero-foot center" style="padding: 2rem;">
                    <div id="grid" style="width: 768px;">
                        <div id="a" class="center-column">
                            <p class="has-text-centered has-text-back">
                            Hi I am Sungjemnula Amri and I'm currently working in Pullman, New Delhi. The Hospitality Training has helped me gain a lot of knowledge about the Hotel industry. The Life skills training by YouthNet and Quest Alliance has been helpful for me as it has improved my speaking skills and has made me feel more confident in myself.
                            </p>
                            <div id="a" class="center-column">
                            <img src="<?php echo base_url(); ?>images/avatar-4.jpg" style=" height:100px;width:100px;border-radius:50%;">

                        </div>



                        <div id="e" class="" >
                            <p  class="is-danger is-inverted is-rounded is-white is-outlined has-text-weight-bold"
                                style="width: 100%; ">
                                Sungjemnula Amri
                            </p>
                        </div>
                    </div>
					</div>
                </main>
            </div>
            <div class='carousel-item' style="width:100%;height:380px;">
                <main class="hero-foot center" style="padding: 2rem;">
                    <div id="grid" style="width: 768px;">
                        <div id="a" class="center-column">
                            <p class="has-text-centered has-text-black">
                            "We got our job through Nagaland Job Centre and now  at Pantaloons, Dimapur. If you want to be employed you should get registered at NJC."
                            </p>
                            <div id="a" class="center-column">
                            <img src="<?php echo base_url(); ?>images/avatar-4.jpg" style=" height:100px;width:100px;border-radius:50%;">

                        </div>



                        <div id="e" class="">
                            <p  class="is-danger is-inverted is-rounded is-white is-outlined has-text-weight-bold"
                                style="color:black;width: 100%; ">
                                Mhabemo & Samuel
                            </p>
                        </div>
                    </div>
					</div>
                </main>
            </div>
            <div class='carousel-item' style="width:100%;height:380px;">
                <main class="hero-foot center" style="padding: 2rem;">
                    <div id="grid" style="width: 768px;">
                        <div id="a" class="center-column">
                            <p class="has-text-centered has-text-black">
                            The thing I appreciate most about NJC is that it has given me the opportunity to find me a stable job in a private sector which was beyond my expectation, NJC management team is a group of very <strong class=has-text-warning   > talented, dedicated, hardworking and friendly </strong> people who makes sure that every individual who come looking for a job are, respected and valued, and encourage youth to go above and beyond.
                            </p>
                            <div id="a" class="center-column">
                            <img src="<?php echo base_url(); ?>images/avatar-4.jpg" style=" height:100px;width:100px;border-radius:50%;">

                        </div>



                        <div id="e" class="">
                            <p  class="is-danger is-inverted is-rounded is-white is-outlined has-text-weight-bold"
                                style="width: 100%; ">
                                Thungchobeni Ngullie, placed with Tribal Group
                            </p>
                        </div>
                    </div>
					</div>
                </main>
            </div>
            <div class='carousel-item' style="width:100%;height:680px;">
                <main class="hero-foot center" style="padding: 2rem;">
                    <div id="grid" style="width: 768px;">
                        <div id="a" class="center-column">
                            <p class="has-text-centered has-text-black">
                            I would like to <strong class=has-text-warning   >commend </strong>Youth Net on the remarkable work they are doing especially on their initiatives in Nagaland  Job Centre. In the few years I’ve had to associate with them, I have come to appreciate the difficult task they have taken upon themselves. Our Naga youth have a lot of potential but are lacking in basic skills, motivation, drive and exposure , which is a cause for concern and it is hoped that the<strong class=has-text-warning   > initiatives </strong> undertaken by YouthNet  will bring about a <strong class=has-text-warning   >change </strong> in our  youth especially in their attitude towards work.
                            </p>
                            <div id="a" class="center-column">
                            <img src="<?php echo base_url(); ?>images/avatar-4.jpg" style=" height:100px;width:100px;border-radius:50%;">

                        </div>



                        <div id="e" class="" style="">
                            <p  class="is-danger is-inverted is-rounded is-white is-outlined has-text-weight-bold"
                                style="color:;width: 100%; ">
                                Vilosa Sakhrie, Café Planet Earth
                            </p>
                        </div>
                    </div>
					</div>
                </main>
            </div>

        </div>
        <div class="carousel-navigation is-overlay">
            <div class="carousel-nav-left">
            <i class="fa fa-chevron-left" aria-hidden="true"></i>
            </div>
            <div class="carousel-nav-right">
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            </div>
        </div>
    </div> 
    
</section> -->


					<div class="modal" id="my-modal">
                        <div class="modal-background"></div>
                            <div class="modal-card">
                                <header class="modal-card-head header-hidden" style="position:inherit !important">
                                <p class="modal-card-title">Job Details</p>
                                <button aria-label="close" class="delete close-modal" data-modal-id="#my-modal"></button>
                                </header>
                                <section class="modal-card-body">
																	<div class="content">
							 											 <div id="grid">
							 												 <?php
							 														//$job_title=$jobs[0]['job_title'];
							 														$job_title=$job->job_title;
							 														$job_title_length=strlen($job_title);
							 														$job_title_length>42 ? $job_title=substr($job_title,0,38).' . . .' : $job_title;
							 													?>
							 													 <div id="b" class="" style="<?php //echo $title_margin; ?>">
							 															 <h4 class="has-text-black" ><?php echo  $job_title; ?></h4>
							 															 <?php
							 																	 $company=$job->company;
							 																	 $company = strlen($company)>27? $company=substr($company,0,27).' . . .' : $company;
							 																?>
							 															 <p class="has-text-grey" style="margin-top:-15px;font-weight:300;font-size:17px;"><?php echo $company ; ?></p>
							 															 <p style="background:#000;display:block;content:' ';height:2px;margin-bottom:20px;margin-top:-8px;"></p>
							 													 </div>
							 											 </div>
							 											 <div id="grid" style="margin-bottom:20px;">
							 													 <div id="b" class="">
							 															 <p class="has-text-grey" style="margin-top:-25px"><?php echo $job->job_experience; ?></p>
							 													 </div>
							 													 <div id="c" class=" ">
							 														 <p class="has-text-grey" style="margin-top:-25px;"> <i class="fas fa-map-marker-alt is-warning" style="margin-top:-25px;color:green"></i>&nbsp;<?php echo $job->job_location; ?></p>
							 													 </div>
							 											 </div>
							 											 <?php
							 													 $summary_height=$job_title_length<25? 'min-height:104px' : 'min-height:82px';
							 													 $summary=$job->job_summary;
							 													 $summary = strlen($summary)>95? $summary=substr($summary,0,95).' . . .' : $summary;
							 												?>
							 											 <p class="has-text-grey" id="home-job-listing-card" style="margin-top:10px;background:;padding:0;<?php echo $summary_height; ?>"><?php echo $summary; ?></p>
							 										 </div>
									abc


                                </section>
                                <footer class="modal-card-foot">
                                <button class="button is-success">Save changes</button>
                                <button class="button" class="delete close-modal" data-modal-id="#my-modal" >Cancel</button>

                                </footer>
                            </div>
                        </div>

<!--/.section carouso -->

<!-- .Footer -->
<?php $this->load->view('common/footer'); ?>
<!-- /.Footer -->

<!-- .Scripts -->
<?php $this->load->view('common/scripts'); ?>
<!-- /.Scripts -->


</body>
</html>
